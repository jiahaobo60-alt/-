package org.example;

/**
 * 停车场用户类型枚举
 */
public enum CarParkKind {
    STAFF,      // 员工
    STUDENT,    // 学生
    MANAGEMENT, // 管理层
    VISITOR     // 访客（免费）
}
