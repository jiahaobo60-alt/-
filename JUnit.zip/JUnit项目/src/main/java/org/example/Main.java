
package org.example;

import java.math.BigDecimal;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // 1. 定义正常时段和优惠时段（例如：正常时段8-18点，优惠时段18-22点）
        ArrayList<Period> normalPeriods = new ArrayList<>();
        normalPeriods.add(new Period(8, 18)); // 8:00-18:00

        ArrayList<Period> reducedPeriods = new ArrayList<>();
        reducedPeriods.add(new Period(18, 22)); // 18:00-22:00

        // 2. 定义费率（正常费率5元/小时，优惠费率3元/小时）
        //    用户类型为员工（STAFF）
        Rate staffRate = new Rate(
                CarParkKind.STAFF,
                reducedPeriods,
                normalPeriods,
                new BigDecimal("5.0"),
                new BigDecimal("3.0")
        );

        // 3. 模拟停车时段（例如：10:00-20:00，共10小时）
        Period parkingPeriod = new Period(10, 20);

        // 4. 计算停车费用
        BigDecimal cost = staffRate.calculate(parkingPeriod);
        System.out.println("员工停车费用：" + cost + "元"); // 预期结果：(18-10)*5 + (20-18)*3 = 40 + 6 = 46元
    }
}