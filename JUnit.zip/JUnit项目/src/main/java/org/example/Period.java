package org.example;

import java.util.List;

/**
 * Period类 - 表示一个时间段
 * 用于停车场收费系统中定义正常时段和优惠时段
 */
public class Period {
    private int startHour;
    private int endHour;

    /**
     * 构造函数
     * @param start 起始小时 (0-24)
     * @param end 结束小时 (0-24)
     */
    public Period(int start, int end) {
        // 前置条件过滤：检查所有无效输入组合
        if (start < 0 && end < 0) {
            throw new IllegalArgumentException("Start Period <0 && End Period < 0");
        } else if (start < 0 && end > 24) {
            throw new IllegalArgumentException("Start Period <0 && End Period > 24");
        } else if (start > 24 && end < 0) {
            throw new IllegalArgumentException("Start Period >24 && End Period < 0");
        } else if (start > 24 && end > 24) {
            throw new IllegalArgumentException("Start Period >24 && End Period > 24");
        } else if (start < 0 && this.validPeriod(end)) {
            throw new IllegalArgumentException("Start Period < 0 && End Period valid");
        } else if (start > 24 && this.validPeriod(end)) {
            throw new IllegalArgumentException("Start Period > 24 && End Period valid");
        } else if (this.validPeriod(start) && end < 0) {
            throw new IllegalArgumentException("Start Period valid && End Period < 0");
        } else if (this.validPeriod(start) && end > 24) {
            throw new IllegalArgumentException("Start Period valid && End Period > 24");
        }

        // 检查起始和结束时间的有效范围
        if (!validPeriod(start) || !validPeriod(end)) {
            throw new IllegalArgumentException("start of period and end of period must be between 0 and 24");
        }

        // 检查起始时间必须小于结束时间
        if (start >= end) {
            throw new IllegalArgumentException("start of period cannot be later or equal to end of period");
        }

        this.startHour = start;
        this.endHour = end;
    }

    /**
     * 验证时间值是否在有效范围内
     */
    private boolean validPeriod(int value) {
        return value >= 0 && value <= 24;
    }

    /**
     * 检查给定小时是否在此时段内
     */
    public boolean isIn(int hour) {
        return hour >= startHour && hour < endHour;
    }

    /**
     * 检查给定小时是否在时段列表中的任一时段内
     */
    public static boolean isIn(int hour, List<Period> list) {
        for (Period period : list) {
            if (period.isIn(hour)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 计算此时段与给定时段列表的重叠小时数
     */
    public int occurrences(List<Period> list) {
        int count = 0;
        for (int hour = startHour; hour < endHour; hour++) {
            if (isIn(hour, list)) {
                count++;
            }
        }
        return count;
    }

    /**
     * 检查此时段是否与另一时段重叠
     */
    public boolean overlaps(Period period) {
        return this.endHour > period.startHour && this.startHour < period.endHour;
    }

    // Getters
    public int getStartHour() {
        return startHour;
    }

    public int getEndHour() {
        return endHour;
    }

    @Override
    public String toString() {
        return "Period{" + startHour + "-" + endHour + "}";
    }
}
