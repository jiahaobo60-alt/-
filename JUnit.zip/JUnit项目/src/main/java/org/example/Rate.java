package org.example;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Rate类 - 停车场费率计算
 */
public class Rate {
    private CarParkKind kind;
    private ArrayList<Period> reducedPeriods;
    private ArrayList<Period> normalPeriods;
    private BigDecimal normalRate;
    private BigDecimal reducedRate;

    /**
     * 完整构造函数
     */
    public Rate(CarParkKind kind, ArrayList<Period> reducedPeriods,
                ArrayList<Period> normalPeriods, BigDecimal normalRate,
                BigDecimal reducedRate) {
        
        // 验证费率范围
        validateRates(normalRate, reducedRate);
        
        // 验证时段列表
        validatePeriods(reducedPeriods, normalPeriods);

        this.kind = kind;
        this.reducedPeriods = reducedPeriods;
        this.normalPeriods = normalPeriods;
        this.normalRate = normalRate;
        this.reducedRate = reducedRate;
    }

    /**
     * 简化构造函数 - 仅验证费率
     */
    public Rate(BigDecimal normalRate, BigDecimal reducedRate) {
        validateRates(normalRate, reducedRate);
        this.normalRate = normalRate;
        this.reducedRate = reducedRate;
    }

    /**
     * 简化构造函数 - 仅验证时段
     */
    public Rate(ArrayList<Period> reducedPeriods, ArrayList<Period> normalPeriods) {
        validatePeriods(reducedPeriods, normalPeriods);
        this.reducedPeriods = reducedPeriods;
        this.normalPeriods = normalPeriods;
    }

    /**
     * 验证费率
     */
    private void validateRates(BigDecimal normalRate, BigDecimal reducedRate) {
        // 检查费率组合的各种无效情况
        if (normalRate.compareTo(BigDecimal.ZERO) < 0 && reducedRate.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("normal rate < 0 && reduced rate < 0");
        }
        if (normalRate.compareTo(BigDecimal.ZERO) < 0 && reducedRate.compareTo(BigDecimal.TEN) > 0) {
            throw new IllegalArgumentException("normal rate < 0 && reduced rate > 10");
        }
        if (normalRate.compareTo(BigDecimal.TEN) > 0 && reducedRate.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("normal rate > 10 && reduced rate < 0");
        }
        if (normalRate.compareTo(BigDecimal.TEN) > 0 && reducedRate.compareTo(BigDecimal.TEN) > 0) {
            throw new IllegalArgumentException("normal rate > 10 && reduced rate > 10");
        }
        if (normalRate.compareTo(BigDecimal.ZERO) < 0 && validRate(reducedRate)) {
            throw new IllegalArgumentException("normal rate < 0 && reduced rate valid");
        }
        if (normalRate.compareTo(BigDecimal.TEN) > 0 && validRate(reducedRate)) {
            throw new IllegalArgumentException("normal rate > 10 && reduced rate valid");
        }
        if (validRate(normalRate) && reducedRate.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("normal rate valid && reduced rate < 0");
        }
        if (validRate(normalRate) && reducedRate.compareTo(BigDecimal.TEN) > 0) {
            throw new IllegalArgumentException("normal rate valid && reduced rate > 10");
        }
        
        // 正常费率必须大于优惠费率
        if (normalRate.compareTo(reducedRate) <= 0) {
            throw new IllegalArgumentException("The normal rate cannot be less or equal to the reduced rate");
        }
    }

    /**
     * 验证时段列表
     */
    private void validatePeriods(ArrayList<Period> reducedPeriods, ArrayList<Period> normalPeriods) {
        boolean normalValid = isValidPeriods(normalPeriods);
        boolean reducedValid = isValidPeriods(reducedPeriods);

        if (normalValid && !reducedValid) {
            throw new IllegalArgumentException("normal period valid && reduced period invalid");
        } else if (!normalValid && reducedValid) {
            throw new IllegalArgumentException("normal period invalid && reduced period valid");
        } else if (!normalValid && !reducedValid) {
            throw new IllegalArgumentException("normal period invalid && reduced period invalid");
        }

        // 检查正常时段和优惠时段是否重叠
        if (!noOverlaps(reducedPeriods, normalPeriods)) {
            throw new IllegalArgumentException("The periods overlaps");
        }
    }


    /**
     * 检查费率是否在有效范围内 (0-10)
     */
    private boolean validRate(BigDecimal rate) {
        return rate.compareTo(BigDecimal.ZERO) >= 0 && rate.compareTo(BigDecimal.TEN) <= 0;
    }

    /**
     * 检查两个时段列表是否不重叠
     */
    private boolean noOverlaps(ArrayList<Period> periods1, ArrayList<Period> periods2) {
        for (Period p1 : periods1) {
            for (Period p2 : periods2) {
                if (p1.overlaps(p2)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 检查单个时段是否与时段列表中的任何时段重叠
     */
    private boolean isValidPeriod(Period period, List<Period> list) {
        for (Period p : list) {
            if (period.overlaps(p)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 检查时段列表内部是否有重叠
     */
    private boolean isValidPeriods(ArrayList<Period> list) {
        if (list == null || list.isEmpty()) {
            return true;
        }
        for (int i = 0; i < list.size(); i++) {
            for (int j = i + 1; j < list.size(); j++) {
                if (list.get(i).overlaps(list.get(j))) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 计算停车费用
     * @param periodStay 停留时段
     * @return 费用金额
     */
    public BigDecimal calculate(Period periodStay) {
        // 访客免费
        if (kind == CarParkKind.VISITOR) {
            return BigDecimal.ZERO;
        }

        // 计算正常时段和优惠时段的小时数
        int normalHours = periodStay.occurrences(normalPeriods);
        int reducedHours = periodStay.occurrences(reducedPeriods);

        // 计算总费用
        BigDecimal normalCost = normalRate.multiply(new BigDecimal(normalHours));
        BigDecimal reducedCost = reducedRate.multiply(new BigDecimal(reducedHours));

        return normalCost.add(reducedCost);
    }

    // Getters
    public CarParkKind getKind() {
        return kind;
    }

    public BigDecimal getNormalRate() {
        return normalRate;
    }

    public BigDecimal getReducedRate() {
        return reducedRate;
    }
}
