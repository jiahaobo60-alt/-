package org.example;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Period类的单元测试
 */
public class PeriodTest {

    // ==================== 前置条件过滤测试 ====================

    @Test
    @DisplayName("测试1: 起始时段 < 0 且 结束时段有效")
    void test1_StartLessThanZero_EndValid() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Period(-2, 6)
        );
        assertTrue(exception.getMessage().contains("Start Period < 0"));
    }

    @Test
    @DisplayName("测试2: 起始时段 > 24 且 结束时段有效")
    void test2_StartGreaterThan24_EndValid() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Period(25, 6)
        );
        assertTrue(exception.getMessage().contains("Start Period > 24"));
    }

    @Test
    @DisplayName("测试3: 起始时段有效 且 结束时段 < 0")
    void test3_StartValid_EndLessThanZero() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Period(6, -2)
        );
        assertTrue(exception.getMessage().contains("End Period < 0"));
    }

    @Test
    @DisplayName("测试4: 起始时段有效 且 结束时段 > 24")
    void test4_StartValid_EndGreaterThan24() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Period(6, 25)
        );
        assertTrue(exception.getMessage().contains("End Period > 24"));
    }

    @Test
    @DisplayName("测试5: 起始时段 < 0 且 结束时段 < 0")
    void test5_BothLessThanZero() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Period(-2, -1)
        );
        assertTrue(exception.getMessage().contains("< 0"));
    }

    @Test
    @DisplayName("测试6: 起始时段 > 24 且 结束时段 > 24")
    void test6_BothGreaterThan24() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Period(25, 26)
        );
        assertTrue(exception.getMessage().contains("> 24"));
    }

    @Test
    @DisplayName("测试7: 起始时段 < 0 且 结束时段 > 24")
    void test7_StartLessThanZero_EndGreaterThan24() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Period(-1, 25)
        );
        assertNotNull(exception.getMessage());
    }

    @Test
    @DisplayName("测试8: 起始时段 > 24 且 结束时段 < 0")
    void test8_StartGreaterThan24_EndLessThanZero() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Period(25, -1)
        );
        assertNotNull(exception.getMessage());
    }

    // ==================== 业务逻辑测试 ====================

    @Test
    @DisplayName("测试9: 起始时段 >= 结束时段")
    void test9_StartGreaterOrEqualEnd() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Period(23, 6)
        );
        assertEquals("start of period cannot be later or equal to end of period", 
            exception.getMessage());
    }

    @Test
    @DisplayName("测试10: 起始时段 == 结束时段")
    void test10_StartEqualsEnd() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Period(6, 6)
        );
        assertEquals("start of period cannot be later or equal to end of period", 
            exception.getMessage());
    }

    // ==================== 有效输入测试 ====================

    @Test
    @DisplayName("测试11: 有效时段创建")
    void test11_ValidPeriod() {
        Period period = new Period(6, 12);
        assertEquals(6, period.getStartHour());
        assertEquals(12, period.getEndHour());
    }

    @Test
    @DisplayName("测试12: 边界值 0-24")
    void test12_BoundaryValues() {
        Period period = new Period(0, 24);
        assertEquals(0, period.getStartHour());
        assertEquals(24, period.getEndHour());
    }

    // ==================== 功能测试 ====================

    @Test
    @DisplayName("测试13: isIn方法 - 小时在时段内")
    void test13_IsIn_HourInPeriod() {
        Period period = new Period(6, 12);
        assertTrue(period.isIn(8));
    }

    @Test
    @DisplayName("测试14: isIn方法 - 小时不在时段内")
    void test14_IsIn_HourNotInPeriod() {
        Period period = new Period(6, 12);
        assertFalse(period.isIn(15));
    }

    @Test
    @DisplayName("测试15: overlaps方法 - 时段重叠")
    void test15_Overlaps_True() {
        Period period1 = new Period(6, 12);
        Period period2 = new Period(10, 15);
        assertTrue(period1.overlaps(period2));
    }

    @Test
    @DisplayName("测试16: overlaps方法 - 时段不重叠")
    void test16_Overlaps_False() {
        Period period1 = new Period(6, 10);
        Period period2 = new Period(12, 15);
        assertFalse(period1.overlaps(period2));
    }

    @Test
    @DisplayName("测试17: overlaps方法 - 边界情况（相邻不重叠）")
    void test17_Overlaps_Adjacent() {
        Period period1 = new Period(6, 10);
        Period period2 = new Period(10, 15);
        assertFalse(period1.overlaps(period2));
    }

    @Test
    @DisplayName("测试18: overlaps分支覆盖 - 外层true内层false")
    void test18_Overlaps_BranchCoverage() {
        Period period1 = new Period(8, 9);
        Period period2 = new Period(0, 6);
        // this.endHour(9) > period.startHour(0) = true
        // this.startHour(8) < period.endHour(6) = false
        assertFalse(period1.overlaps(period2));
    }
}
