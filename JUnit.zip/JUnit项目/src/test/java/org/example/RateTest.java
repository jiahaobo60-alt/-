package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Rate类的单元测试
 */
public class RateTest {

    private ArrayList<Period> normalList;
    private ArrayList<Period> reducedList;
    private BigDecimal normalRate;
    private BigDecimal reducedRate;

    @BeforeEach
    void setUp() {
        normalList = new ArrayList<>();
        reducedList = new ArrayList<>();
        normalRate = new BigDecimal("5");
        reducedRate = new BigDecimal("2");
    }

    // ==================== 费率验证测试 ====================

    @Test
    @DisplayName("测试1: 正常费率 < 0 且 优惠费率有效")
    void test1_NormalRateLessThanZero_ReducedValid() {
        BigDecimal invalidNormal = new BigDecimal("-1");
        assertThrows(IllegalArgumentException.class,
            () -> new Rate(invalidNormal, reducedRate));
    }

    @Test
    @DisplayName("测试2: 正常费率 > 10 且 优惠费率有效")
    void test2_NormalRateGreaterThan10_ReducedValid() {
        BigDecimal invalidNormal = new BigDecimal("11");
        assertThrows(IllegalArgumentException.class,
            () -> new Rate(invalidNormal, reducedRate));
    }

    @Test
    @DisplayName("测试3: 正常费率有效 且 优惠费率 < 0")
    void test3_NormalValid_ReducedLessThanZero() {
        BigDecimal invalidReduced = new BigDecimal("-1");
        assertThrows(IllegalArgumentException.class,
            () -> new Rate(normalRate, invalidReduced));
    }

    @Test
    @DisplayName("测试4: 正常费率有效 且 优惠费率 > 10")
    void test4_NormalValid_ReducedGreaterThan10() {
        BigDecimal invalidReduced = new BigDecimal("11");
        assertThrows(IllegalArgumentException.class,
            () -> new Rate(normalRate, invalidReduced));
    }

    @Test
    @DisplayName("测试5: 正常费率 < 0 且 优惠费率 < 0")
    void test5_BothLessThanZero() {
        BigDecimal invalidNormal = new BigDecimal("-1");
        BigDecimal invalidReduced = new BigDecimal("-2");
        assertThrows(IllegalArgumentException.class,
            () -> new Rate(invalidNormal, invalidReduced));
    }

    @Test
    @DisplayName("测试6: 正常费率 < 0 且 优惠费率 > 10")
    void test6_NormalLessThanZero_ReducedGreaterThan10() {
        BigDecimal invalidNormal = new BigDecimal("-1");
        BigDecimal invalidReduced = new BigDecimal("11");
        assertThrows(IllegalArgumentException.class,
            () -> new Rate(invalidNormal, invalidReduced));
    }

    @Test
    @DisplayName("测试7: 正常费率 > 10 且 优惠费率 < 0")
    void test7_NormalGreaterThan10_ReducedLessThanZero() {
        BigDecimal invalidNormal = new BigDecimal("11");
        BigDecimal invalidReduced = new BigDecimal("-1");
        assertThrows(IllegalArgumentException.class,
            () -> new Rate(invalidNormal, invalidReduced));
    }

    @Test
    @DisplayName("测试8: 正常费率 > 10 且 优惠费率 > 10")
    void test8_BothGreaterThan10() {
        BigDecimal invalidNormal = new BigDecimal("11");
        BigDecimal invalidReduced = new BigDecimal("12");
        assertThrows(IllegalArgumentException.class,
            () -> new Rate(invalidNormal, invalidReduced));
    }

    @Test
    @DisplayName("测试9: 正常费率 <= 优惠费率")
    void test9_NormalLessOrEqualReduced() {
        BigDecimal lowNormal = new BigDecimal("2");
        BigDecimal highReduced = new BigDecimal("5");
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Rate(lowNormal, highReduced));
        assertTrue(exception.getMessage().contains("normal rate cannot be less or equal"));
    }

    // ==================== 时段验证测试 ====================

    @Test
    @DisplayName("测试10: 正常列表有效 且 优惠列表无效（内部重叠）")
    void test10_NormalValid_ReducedInvalid() {
        reducedList.add(new Period(0, 6));
        reducedList.add(new Period(4, 8));  // 与上一个重叠
        normalList.add(new Period(10, 12));
        
        assertThrows(IllegalArgumentException.class,
            () -> new Rate(reducedList, normalList));
    }

    @Test
    @DisplayName("测试11: 正常列表无效 且 优惠列表有效")
    void test11_NormalInvalid_ReducedValid() {
        normalList.add(new Period(10, 14));
        normalList.add(new Period(12, 16));  // 与上一个重叠
        reducedList.add(new Period(0, 6));
        
        assertThrows(IllegalArgumentException.class,
            () -> new Rate(reducedList, normalList));
    }

    @Test
    @DisplayName("测试12: 正常列表无效 且 优惠列表无效")
    void test12_BothInvalid() {
        normalList.add(new Period(10, 14));
        normalList.add(new Period(12, 16));
        reducedList.add(new Period(0, 6));
        reducedList.add(new Period(4, 8));
        
        assertThrows(IllegalArgumentException.class,
            () -> new Rate(reducedList, normalList));
    }

    @Test
    @DisplayName("测试13: 正常列表与优惠列表重叠")
    void test13_NormalAndReducedOverlap() {
        normalList.add(new Period(8, 16));
        reducedList.add(new Period(14, 20));  // 与正常时段重叠
        
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> new Rate(reducedList, normalList));
        assertTrue(exception.getMessage().contains("overlaps"));
    }


    // ==================== 费用计算测试 ====================

    @Test
    @DisplayName("测试14: 有效Rate创建")
    void test14_ValidRateCreation() {
        normalList.add(new Period(7, 17));
        reducedList.add(new Period(0, 7));
        reducedList.add(new Period(17, 24));
        
        Rate rate = new Rate(CarParkKind.STAFF, reducedList, normalList, 
            normalRate, reducedRate);
        assertNotNull(rate);
    }

    @Test
    @DisplayName("测试15: 非访客费用计算")
    void test15_CalculateNonVisitor() {
        reducedList.add(new Period(0, 7));
        normalList.add(new Period(7, 24));
        
        Rate rate = new Rate(CarParkKind.STAFF, reducedList, normalList,
            new BigDecimal("10"), new BigDecimal("4"));
        
        Period stayPeriod = new Period(5, 10);
        // 5-7: 2小时优惠时段 = 2 * 4 = 8
        // 7-10: 3小时正常时段 = 3 * 10 = 30
        // 总计: 38
        BigDecimal expected = new BigDecimal("38");
        assertEquals(expected, rate.calculate(stayPeriod));
    }

    @Test
    @DisplayName("测试16: 访客免费")
    void test16_CalculateVisitor() {
        reducedList.add(new Period(0, 7));
        normalList.add(new Period(7, 24));
        
        Rate rate = new Rate(CarParkKind.VISITOR, reducedList, normalList,
            normalRate, reducedRate);
        
        Period stayPeriod = new Period(5, 15);
        assertEquals(BigDecimal.ZERO, rate.calculate(stayPeriod));
    }

    @Test
    @DisplayName("测试17: 仅在正常时段停留")
    void test17_CalculateOnlyNormalPeriod() {
        reducedList.add(new Period(0, 7));
        normalList.add(new Period(7, 24));
        
        Rate rate = new Rate(CarParkKind.STUDENT, reducedList, normalList,
            new BigDecimal("5"), new BigDecimal("2"));
        
        Period stayPeriod = new Period(8, 12);
        // 4小时正常时段 = 4 * 5 = 20
        BigDecimal expected = new BigDecimal("20");
        assertEquals(expected, rate.calculate(stayPeriod));
    }

    @Test
    @DisplayName("测试18: 仅在优惠时段停留")
    void test18_CalculateOnlyReducedPeriod() {
        reducedList.add(new Period(0, 7));
        normalList.add(new Period(7, 24));
        
        Rate rate = new Rate(CarParkKind.MANAGEMENT, reducedList, normalList,
            new BigDecimal("5"), new BigDecimal("2"));
        
        Period stayPeriod = new Period(2, 6);
        // 4小时优惠时段 = 4 * 2 = 8
        BigDecimal expected = new BigDecimal("8");
        assertEquals(expected, rate.calculate(stayPeriod));
    }

    @Test
    @DisplayName("测试19: 边界值费率 0 和 10")
    void test19_BoundaryRates() {
        normalList.add(new Period(7, 17));
        reducedList.add(new Period(0, 7));
        
        // 正常费率10，优惠费率接近0但大于0
        Rate rate = new Rate(CarParkKind.STAFF, reducedList, normalList,
            new BigDecimal("10"), new BigDecimal("0.01"));
        assertNotNull(rate);
    }
}
